// Feito por Guilherme Rosseti
#include <stdio.h>
#include <stdlib.h>

int main() {
  for (int i = 15; i < 31; i++) {
    printf("%d ", i*i);
    
  }
  
  return 0;
}