// bibliotecas basicas (standard input/output e standard library)
#include <stdio.h>
#include <stdlib.h>

// Função principal (todo o codigo fica dentro dela)
int main() {
    // printf para mostrar algo no prompt
    printf("Ola Mundo!");
    // Retorna 0 se o código foi executado por completo 
    return 0;
}