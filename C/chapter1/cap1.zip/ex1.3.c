#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("########\n");
    // Looping for - recebe 3 instruções 
    //a variavel que será usada no loop
    //até qual valor dessa variavel o loop vai acontecer
    //qual operação será feita com essa variavel em todos os loops 
    for (int i = 0; i < 4; i++) {
        printf("#      #\n");
    }
        printf("########\n");
}